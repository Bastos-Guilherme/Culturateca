package com.culturateca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CulturatecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CulturatecaApplication.class, args);
	}

}
